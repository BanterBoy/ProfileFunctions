function Get-DuckDuckGoSearch {
    Start-Process "https://duckduckgo.com/?q=$args"
}